/-
Axiom audit for the r = 6 (Sneiderman) formalization. ROUND-6 Task B.

Run with:  lake env lean AxiomAuditR6.lean

Expected axiom profile for EVERY declaration below, at every increment of this
campaign: exactly the three standard Lean axioms

  propext, Classical.choice, Quot.sound

and nothing else. Unlike the r = 5 lane, this campaign uses no SAT primitives and no
`native_decide`, so the four SAT-reflection axioms of `Lean617.Primitives` must never
appear here — see FORMAL.md §S3. There must be NO `sorryAx`.

Held mathematical hypotheses (exactly one: `BrooksSix`, defined in increment 8 as
the §S1 pinned Zając form and discharged in increment 9) are hypothesis variables
(binders), not axioms, and so do not appear in `#print axioms`; they are
discharged by the caller and audited separately.

Known LEANER lines (subsets of the three standard axioms — not deviations):
`Main6` and `comap_compl_eq` and `mul_slack_bound` at `[propext, Quot.sound]`,
`sq_mid_bound` at `[propext]`; from increment 9, `Brooks.PProper` at no axioms
and `Brooks.partialOf` / `Brooks.partialOf_eq_none_iff` at `[propext,
Quot.sound]`. A profile is a breach only if it contains an axiom OUTSIDE the
standard three (`sorryAx`, `ofReduceBool`, SAT reflection, ...).
-/
import Lean617.R6.Statements
import Lean617.R6.Prelim
import Lean617.R6.Terminal
import Lean617.R6.P3
import Lean617.R6.Q19
import Lean617.R6.H25P4
import Lean617.R6.T31
import Lean617.R6.Final
import Lean617.R6.Brooks

-- Increment 1: the statement layer and the colouring/graph-theory interface.
#print axioms Erdos617.R6.Main6
#print axioms Erdos617.R6.main6_iff_no_balanced
#print axioms Erdos617.R6.main6_imp_upstream
#print axioms Erdos617.R6.main6_imp_upstreamErdos617
#print axioms Erdos617.R6.Admissible.comap
#print axioms Erdos617.R6.Admissible.of_le
#print axioms Erdos617.R6.indep_le_six
#print axioms Erdos617.R6.cap_sixteen
#print axioms Erdos617.R6.balanced_gives_admissible
#print axioms Erdos617.R6.least_colour_class
#print axioms Erdos617.R6.sum_edgeCountIn_colourClass6

-- Increment 2: Sneiderman's §2 preliminaries (Lemma 2.4 averaging chain first, per FB-4).
#print axioms Erdos617.R6.card_filter_erase_sym2
#print axioms Erdos617.R6.sum_edgeCountIn_erase
#print axioms Erdos617.R6.exists_erase_edgeCountIn_le
#print axioms Erdos617.R6.exists_subset_edgeCountIn_le
#print axioms Erdos617.R6.exists_subset_card_edgeCountIn_le
#print axioms Erdos617.R6.alphaAtMost_complClosedNbhd
#print axioms Erdos617.R6.choose_two_le_edgeCountIn_clique
#print axioms Erdos617.R6.edgeCountIn_insert_add_two_le
#print axioms Erdos617.R6.peel_nbr_le_one
#print axioms Erdos617.R6.peel_alpha
#print axioms Erdos617.R6.peel_edges
#print axioms Erdos617.R6.two_mul_choose_two
#print axioms Erdos617.R6.card_filter_mem_sym2_le_two
#print axioms Erdos617.R6.card_filter_mem_both_le_one
#print axioms Erdos617.R6.choose_two_le_card_edges_meeting_nbhd
#print axioms Erdos617.R6.edgeCountIn_complClosedNbhd_le

-- Increment 3: Lemma 2.5, the terminal complement (R6/Terminal.lean).
#print axioms Erdos617.R6.edgeCountIn_eq_zero_of_isIndep
#print axioms Erdos617.R6.edgeCountIn_insert_le
#print axioms Erdos617.R6.nbrInto
#print axioms Erdos617.R6.nbrInto_add_le
#print axioms Erdos617.R6.isIndep_neighborFinset_of_triangleFree
#print axioms Erdos617.R6.degree_le_of_triangleFree_alphaAtMost
#print axioms Erdos617.R6.card_complClosedNbhd
#print axioms Erdos617.R6.terminal_pair_bound
#print axioms Erdos617.R6.terminal_no_deg5_vertex

-- Increment 4: Proposition 3.1, the 18-vertex clique lemma (R6/P3.lean).
#print axioms Erdos617.R6.no_clique_of_cliqueFree_six
#print axioms Erdos617.R6.sum_ite_mem_pair
#print axioms Erdos617.R6.mem_of_mem_sym2
#print axioms Erdos617.R6.p3_floor
#print axioms Erdos617.R6.p3_edge_split
#print axioms Erdos617.R6.comap_compl_degree_add
#print axioms Erdos617.R6.cross_ge_of_min_degree
#print axioms Erdos617.R6.p3_cross_cover
#print axioms Erdos617.R6.p3_d5_config_false
#print axioms Erdos617.R6.p3_d6_star
#print axioms Erdos617.R6.p3_d5_branch
#print axioms Erdos617.R6.p3_d6_branch
#print axioms Erdos617.R6.prop_P3

-- Increment 5: Proposition 4.1, the 19-vertex clique lemma (R6/Q19.lean).
#print axioms Erdos617.R6.sum_ite_mem_pair_fn
#print axioms Erdos617.R6.sum_endpoint_weight
#print axioms Erdos617.R6.comap_degree_eq
#print axioms Erdos617.R6.sum_transport
#print axioms Erdos617.R6.edge_count_le_cover
#print axioms Erdos617.R6.sum_degree_add_slack_card_le
#print axioms Erdos617.R6.q19_pair_degree_le
#print axioms Erdos617.R6.mul_slack_bound
#print axioms Erdos617.R6.sq_mid_bound
#print axioms Erdos617.R6.comap_compl_eq
#print axioms Erdos617.R6.edgeCountIn_add_compl_inSet
#print axioms Erdos617.R6.alphaAtMost_comap_any
#print axioms Erdos617.R6.q19_d5_config_false
#print axioms Erdos617.R6.q19_delta4_false
#print axioms Erdos617.R6.q19_deg3_closed_triangle
#print axioms Erdos617.R6.q19_support4_false
#print axioms Erdos617.R6.q19_m5_deg_false
#print axioms Erdos617.R6.q19_d6_core
#print axioms Erdos617.R6.q19_pair_uncovered_adj
#print axioms Erdos617.R6.q19_triple_cover
#print axioms Erdos617.R6.q19_d4_branch
#print axioms Erdos617.R6.q19_d5_branch
#print axioms Erdos617.R6.q19_d6_branch
#print axioms Erdos617.R6.prop_Q19

-- Increment 6: the 25- and 24-vertex clique lemmas (R6/H25P4.lean).
#print axioms Erdos617.R6.edgeCountIn_insert_center_le
#print axioms Erdos617.R6.sum_nbr_filter_eq_two_mul
#print axioms Erdos617.R6.k6_of_subset
#print axioms Erdos617.R6.h25_d6_branch
#print axioms Erdos617.R6.prop_H25
#print axioms Erdos617.R6.p4_d5_branch
#print axioms Erdos617.R6.prop_P4

-- Increment 7: the 31-vertex edge floor (R6/T31.lean).
#print axioms Erdos617.R6.k6_of_subset_alpha
#print axioms Erdos617.R6.t31_no_k6
#print axioms Erdos617.R6.t31_terminal
#print axioms Erdos617.R6.t31_d6_branch
#print axioms Erdos617.R6.prop_T31

-- Increment 8: the endgame assembly (R6/Final.lean). `BrooksSix` is the campaign's
-- single held hypothesis — a binder on the two theorems that consume it, NOT an
-- axiom; these lines confirm no axiom snuck in behind it.
#print axioms Erdos617.R6.BrooksSix
#print axioms Erdos617.R6.final_brooks_branch
#print axioms Erdos617.R6.final_t31_branch
#print axioms Erdos617.R6.final_contradiction
#print axioms Erdos617.R6.erdos_617_r6
#print axioms Erdos617.R6.erdos_617_r6_upstream

-- Increment 9: the Brooks discharge (R6/Brooks.lean) and the unconditional
-- theorems. `brooksSix_proven` discharges the campaign's single held
-- hypothesis; `erdos_617_r6_unconditional` and its upstream twin carry NO
-- mathematical hypothesis at all.
#print axioms Erdos617.R6.Brooks.PProper
#print axioms Erdos617.R6.Brooks.exists_free_colour
#print axioms Erdos617.R6.Brooks.blocked_le_degree
#print axioms Erdos617.R6.Brooks.blocked_lt_of_uncoloured_nbr
#print axioms Erdos617.R6.Brooks.blocked_lt_of_collision
#print axioms Erdos617.R6.Brooks.PProper.extend
#print axioms Erdos617.R6.Brooks.colorable_of_total
#print axioms Erdos617.R6.Brooks.pathColor
#print axioms Erdos617.R6.Brooks.exists_first_split
#print axioms Erdos617.R6.Brooks.exists_maximal_path_aux
#print axioms Erdos617.R6.Brooks.exists_maximal_path
#print axioms Erdos617.R6.Brooks.partialOf
#print axioms Erdos617.R6.Brooks.partialOf_eq_none_iff
#print axioms Erdos617.R6.Brooks.partialOf_pproper
#print axioms Erdos617.R6.Brooks.degree_comap_le
#print axioms Erdos617.R6.Brooks.cliqueFree_comap
#print axioms Erdos617.R6.Brooks.colorable_of_no_cross
#print axioms Erdos617.R6.Brooks.exists_nonadj_of_cliqueFree
#print axioms Erdos617.R6.Brooks.colorable_of_delete_extend
#print axioms Erdos617.R6.Brooks.colorable_of_spanning_path
#print axioms Erdos617.R6.Brooks.colorable_of_cycle_patch
#print axioms Erdos617.R6.brooks_strong
#print axioms Erdos617.R6.brooks_zajac
#print axioms Erdos617.R6.brooksSix_proven
#print axioms Erdos617.R6.erdos_617_r6_unconditional
#print axioms Erdos617.R6.erdos_617_r6_upstream_unconditional

-- F3 repair (post-review, r6-unconditional-review-2026-07-30): the eight
-- human-written Statements.lean declarations the audit previously left unnamed.
-- The four compiler-generated forms (Balanced6.eq_1 etc.) are covered by their
-- parents' cones and are not named individually.
#print axioms Erdos617.R6.Admissible
#print axioms Erdos617.R6.Balanced6
#print axioms Erdos617.R6.Misses6
#print axioms Erdos617.R6.UpstreamErdos617
#print axioms Erdos617.R6.colourClass6
#print axioms Erdos617.R6.edgeCountIn_colourClass6
#print axioms Erdos617.R6.edgeCountIn_le_of_le
#print axioms Erdos617.R6.mem_colourClass6_edgeSet
