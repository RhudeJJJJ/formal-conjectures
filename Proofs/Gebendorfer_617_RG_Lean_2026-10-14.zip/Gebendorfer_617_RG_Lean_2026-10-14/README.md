# Erdős 617 (r = 5, 6) and Radenković–Gutman: Lean audit, 14 October 2026

Author of the statement bridges and RG foundations: Jonas J. Gebendorfer, with OpenAI Codex assistance. Third-party mathematical and formal contributions are credited separately below and in the source files. This package contains the complete local source dependencies; only official Lean 4.33.1 and the pinned Mathlib dependency are external.

## Exact scope

| Target | Certificate | Status |
|---|---|---|
| Every 5-edge-colouring of K26 has six vertices missing a colour | `Gebendorfer.Erdos617R5.r_eq_5` | Complete, kernel checked |
| Every 6-edge-colouring of K37 has seven vertices missing a colour | `Gebendorfer.Erdos617R6.r_eq_6` | Complete, kernel checked |
| The analogous two-colour statement on K5 | `Gebendorfer.Erdos617Boundary.r_two_shape_false` | Negated by a kernel-checked C5 witness |
| Radenković–Gutman global path-minimum / strict pendant-path fusion | No complete certificate supplied | Partial formalization only |

The two positive theorems quantify over every finite vertex type of the required cardinality, and every map from unordered pairs to the indicated colour type. Only pairs of distinct vertices are tested. No balancing, surjectivity, regularity, graph classification, conjecture-specific premise, or unproved theorem is assumed in the final theorem types. `Proofs/Erdos617ExactAudit.lean` checks both types explicitly without relying on third-party statement aliases. The general all-r conjecture remains outside these fixed cases.

The R6 arithmetic file separately verifies the finite endpoint arithmetic of Gebendorfer's manuscript under its explicitly stated structural bounds. It is **not** used to pretend that the graph-theoretic derivation of those bounds has been formalized. The full r=6 certificate uses the separately credited earlier route below.

## Provenance and mathematical credit

- Robert Sneiderman's earlier public fixed-case proofs predate Gebendorfer's manuscripts. This package does not assert exclusive priority or transfer authorship of those earlier proofs.
- The r=5 reduction is the 16-module theory closure of Ramazan Kara's `erdos-617-r5-formal-verification`, commit `578c1f3f4ad336a07ab5ea6841042e474bfb3443`. Its explicit remaining special-Brooks premise is discharged here by the general Brooks theorem, rather than by Kara's large SAT certificate route. No SAT data is needed to reproduce this package.
- The generic Brooks formalization is extracted and namespace-renamed from Nick Winter's `nwinter/erdos-617-r5`, commit `32f1bfe6759299ef3a1c6e8b4c3c637528a9881b`, `lean617/Lean617/R6/Brooks.lean`. The mathematical argument is Mariusz Zając's *A short proof of Brooks' theorem*, arXiv:1805.11176. The extraction, current-version adaptation, and composition with Kara's reduction are recorded here.
- The full r=6 proof is Winter's 18-module Lean formalization of Sneiderman's earlier six-colour proof, at the same pinned commit. Its complete required source closure is vendored, adapted to current Mathlib, and compiled afresh. Neither the proof nor its earlier formalization is attributed to Gebendorfer.
- Gebendorfer's relevant written works are DOI `10.5281/zenodo.22344189` (r=5), DOI `10.5281/zenodo.22068988` (r=6), and DOI `10.5281/zenodo.22342611` (RG). The two fixed-case certificates certify the same mathematical statements; they are not line-by-line formalizations of Gebendorfer's later proof routes.

`SOURCE_PINS.json` lists every original and adapted source hash. `r5-lean433.patch` and `r6-lean433.patch` show all version-port changes in the required vendored closures. The original Apache-2.0 licenses are included. Port changes address symmetry-class constructors, renamed Mathlib facts, obsolete no-op tactics, and elaborator transparency; no target conclusion is weakened or introduced as an axiom.

## Reproduce

Install the official Lean 4.33.1 toolchain (normally via elan), then run from the extracted directory:

```sh
python3 verify.py
```

The script installs the pinned Mathlib version through Lake and the official Mathlib cache, compiles every local dependency in topological order, treats warnings as errors in the new `Proofs.*` files, checks all printed axiom profiles against `{propext, Classical.choice, Quot.sound}`, and writes logs plus `build/audit/receipt.json`. Foreign sources may issue non-mathematical style/deprecation warnings. The compiler still kernel-checks every proof.

An existing project with exactly the pinned compatible Mathlib dependency can be reused read-only:

```sh
python3 verify.py --mathlib-project /absolute/path/to/existing/project
```

A fresh local dependency rebuild is always performed; vendored precompiled proof objects are not included. No SAT solver, external oracle, `native_decide`, or private Drive contents are required. The accompanying 125-declaration r=6 audit is also compiled.

## What is proved for RG

The actual graph Laplacian spectrum, Laplacian energy, and mean degree are defined. The following are proved for arbitrary finite vertex types where appropriate:

- the energy/stop-loss identity, including the exact mean `2-2/n` for trees;
- right derivatives of stop-loss, including at eigenvalue thresholds;
- the dimension-free Lipschitz estimate conditional on the explicit spectral-count gap;
- Laplacian addition for disjoint graph unions;
- the exact edge-rewiring difference as two incidence-vector outer products;
- the corresponding Gram equalities and zero trace;
- the all-length polynomial path recurrence, addition identities, singleton cancellation, and quotient recurrence.

Still required for the **global RG theorem** are the actual matrix/resolvent interpretation of the path recurrence, the spectral-count gap from the perturbation, the analytic Schur-disk and integral estimates, the formally complete coverage and inequalities represented by the computer certificates, and the global strict-fusion reduction. Those are mathematical Lean obligations, not merely a slow final build. `PathMinimum` is only a definition of the target; there is no theorem claiming to prove it. Python/Arb replay, private mathematical feedback, and the complete r=5/r=6 certificates do not discharge these RG obligations.
