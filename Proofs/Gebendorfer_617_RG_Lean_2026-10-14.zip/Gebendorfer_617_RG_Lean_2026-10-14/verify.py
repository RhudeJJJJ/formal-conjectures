#!/usr/bin/env python3
"""Compile all local proof dependencies and audit every printed axiom profile.

Requires Python 3, git, and the official Lean/Lake 4.33.1 toolchain.
No SAT solver, native_decide, compiled proof oracle, or private source is used.
Use --mathlib-project to reuse a matching, already installed Mathlib dependency
cache without modifying that project. Otherwise this package installs its pinned
Mathlib dependency through Lake and the official Mathlib cache utility.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mathlib-project', type=Path)
args = parser.parse_args()
env = os.environ.copy()
version = subprocess.check_output(['lean','--version'],env=env,text=True).strip()
if 'version 4.33.1' not in version:
    raise SystemExit('Use the official Lean 4.33.1 toolchain, got: '+version)
project = (args.mathlib_project or ROOT).resolve()
if args.mathlib_project is None:
    subprocess.run(['lake','update'],cwd=ROOT,env=env,check=True)
    subprocess.run(['lake','exe','cache','get'],cwd=ROOT,env=env,check=True)
raw = subprocess.check_output(['lake','env','printenv','LEAN_PATH'],cwd=project,env=env,text=True).strip()
mathlib_paths = ':'.join(str((project/p).resolve()) for p in raw.split(':'))
OUT = ROOT/'build'/'lib'
LOG = ROOT/'build'/'audit'
OUT.mkdir(parents=True,exist_ok=True)
LOG.mkdir(parents=True,exist_ok=True)
env['LEAN_PATH'] = str(OUT)+':'+mathlib_paths
sources = {}
for base in [ROOT,ROOT/'vendor/r5',ROOT/'vendor/r6']:
    for p in base.rglob('*.lean'):
        if base == ROOT and ('vendor' in p.relative_to(ROOT).parts or 'build' in p.relative_to(ROOT).parts or '.lake' in p.parts):
            continue
        if '.lake' not in p.parts:
            sources[str(p.relative_to(base).with_suffix('')).replace('/','.')] = p
roots = ['Proofs.Erdos617ExactAudit','Proofs.Erdos617R6Arithmetic',
         'Proofs.RadenkovicGutmanSpectral','Proofs.RadenkovicGutmanPerturbation',
         'Proofs.RadenkovicGutmanPathRecurrence','AxiomAuditR6']
deps = {}
def collect(n):
    if n in deps:
        return
    deps[n] = {m for m in re.findall(r'^(?:public )?import\s+(\S+)',sources[n].read_text(),re.M) if m in sources}
    for m in deps[n]:
        collect(m)
for root in roots:
    collect(root)
# Check the actual source hashes, including the complete vendored import closures.
pins = json.loads((ROOT/'SOURCE_PINS.json').read_text())
for lane in pins:
    for item in lane['sources']:
        actual = hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()
        if actual != item['adapted_sha256']:
            raise SystemExit('Changed vendored source: '+item['path'])
standard = {'propext','Classical.choice','Quot.sound'}
pending = set(deps)
done = set()
records = []
started = time.monotonic()
print('Lean:',version,flush=True)
print('Fresh local import closure:',len(pending),'modules',flush=True)
while pending:
    ready = sorted(n for n in pending if deps[n] <= done)
    if not ready:
        raise SystemExit('Cyclic local imports: '+str(pending))
    n = ready[0]
    src = sources[n]
    obj = OUT/(n.replace('.','/')+'.olean')
    obj.parent.mkdir(parents=True,exist_ok=True)
    own = n.startswith('Proofs.')
    command = ['lean','-j1']+(['-DwarningAsError=true'] if own else [])+['-o',str(obj),str(src)]
    t = time.monotonic()
    run = subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True,timeout=1800)
    output = run.stdout+run.stderr
    (LOG/(n.replace('.','_')+'.log')).write_text(output)
    profiles = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]",output,re.S)
    for declaration, profile in profiles:
        axioms = {a.strip() for a in profile.split(',') if a.strip()}
        if not axioms <= standard:
            raise SystemExit('Nonstandard axiom on '+declaration+': '+repr(axioms))
    if run.returncode:
        print(output,file=sys.stderr)
        raise SystemExit(run.returncode)
    record = dict(module=n,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),
                  seconds=round(time.monotonic()-t,3),exit_code=run.returncode,
                  warnings='warning:' in output,printed_profiles=len(profiles))
    records.append(record)
    pending.remove(n)
    done.add(n)
    print('PASS',n,record['seconds'],flush=True)
    receipt = dict(lean=version,completed=len(done),closure=len(deps),records=records,
                   seconds=round(time.monotonic()-started,3),
                   fixed_r5='PROVED' if 'Proofs.Erdos617R5Proof' in done else 'PENDING',
                   fixed_r6='PROVED' if 'Proofs.Erdos617R6Proof' in done else 'PENDING',
                   radenkovic_gutman='PARTIAL_FOUNDATIONS_ONLY',
                   standard_axioms_only_in_printed_profiles=True)
    (LOG/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS: both fixed cases, exact-statement audit, r=2 negative control, and RG foundations.',flush=True)
print('RG global path minimum and strict fusion are NOT certified by this package.',flush=True)
