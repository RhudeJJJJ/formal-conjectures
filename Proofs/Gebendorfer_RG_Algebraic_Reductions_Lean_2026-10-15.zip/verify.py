#!/usr/bin/env python3
"""Rebuild the eleven local modules, reject warnings and nonstandard axioms."""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parent
MODULES = ['RadenkovicGutmanPathRecurrence', 'RadenkovicGutmanPathDeterminant', 'RadenkovicGutmanPathResolvent', 'RadenkovicGutmanPathAudit', 'RadenkovicGutmanCoreQuotient', 'RadenkovicGutmanGraphJoin', 'RadenkovicGutmanFusionQuotient', 'RadenkovicGutmanResolventDisk', 'RadenkovicGutmanPathEnclosure', 'RadenkovicGutmanArmBridge', 'RadenkovicGutmanReductionsAudit']
PIN = "0df444a360eaa60ab8c11dca51a86af692955474"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
def run(args, cwd, env=None):
    return subprocess.check_output(args, cwd=cwd, env=env, text=True, stderr=subprocess.STDOUT)
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mathlib-project", type=pathlib.Path)
    args = ap.parse_args()
    if (ROOT / "SHA256SUMS").exists():
        for line in (ROOT / "SHA256SUMS").read_text().splitlines():
            digest, rel = line.split("  ", 1)
            assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == digest, rel
    project = args.mathlib_project.resolve() if args.mathlib_project else ROOT
    if args.mathlib_project is None:
        subprocess.run(["lake", "update"], cwd=ROOT, check=True)
        subprocess.run(["lake", "exe", "cache", "get",
                        "Mathlib.Analysis.Matrix.Spectrum",
                        "Mathlib.LinearAlgebra.Matrix.SchurComplement",
                        "Mathlib.Combinatorics.SimpleGraph.Sum",
                        "Mathlib.Combinatorics.SimpleGraph.Operations",
                        "Mathlib.Combinatorics.SimpleGraph.Hasse",
                        "Mathlib.Tactic.Ring", "Mathlib.Tactic.Linarith",
                        "Mathlib.Tactic.FieldSimp", "Mathlib.Tactic.FinCases",
                        "Mathlib.Tactic.Positivity"], cwd=ROOT, check=True)
    dep = project / ".lake/packages/mathlib"
    assert run(["git", "rev-parse", "HEAD"], dep).strip() == PIN, "Mathlib pin mismatch"
    query = "import os,json;print(json.dumps({k:os.environ[k] for k in ('PATH','LEAN_PATH')}))"
    settings = json.loads(run(["lake", "env", "python3", "-c", query], project))
    env = os.environ.copy(); env.update(settings)
    # Lake can emit relative search roots. Resolve them against its project.
    roots = [str((project / p).resolve()) if not pathlib.Path(p).is_absolute() else p
             for p in env["LEAN_PATH"].split(os.pathsep) if p]
    build = ROOT / "build/rechecked"
    if build.exists(): shutil.rmtree(build)
    build.mkdir(parents=True)
    env["LEAN_PATH"] = os.pathsep.join([str(build)] + roots)
    lean = shutil.which("lean", path=env["PATH"])
    assert lean, "Lean executable unavailable"
    version = run([lean, "--version"], ROOT, env).strip()
    assert "version 4.33.1," in version, version
    receipt = {"lean": version, "mathlib": PIN, "global_rg": "NOT_PROVED", "modules": []}
    started = time.monotonic()
    for module in MODULES:
        source = ROOT / "Proofs" / (module + ".lean")
        assert not re.search(r"\b(sorry|native_decide)\b|^\s*axiom\s", source.read_text(), re.M), module
        output = build / "Proofs" / (module + ".olean")
        output.parent.mkdir(exist_ok=True)
        cmd = [lean, "-DwarningAsError=true", "-DautoImplicit=false", "-DrelaxedAutoImplicit=false", "-o", str(output), str(source)]
        t0 = time.monotonic()
        p = subprocess.run(cmd, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        (build / (module + ".log")).write_text(p.stdout)
        assert p.returncode == 0, p.stdout
        assert not re.search(r"\b(error|warning):", p.stdout), p.stdout
        profiles = []
        for name, axioms in re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", p.stdout):
            used = {x.strip() for x in axioms.split(",") if x.strip()}
            assert used <= ALLOWED, (name, used)
            profiles.append({"name": name, "axioms": sorted(used)})
        assert profiles, "No axiom profiles printed: " + module
        receipt["modules"].append({"name": module, "seconds": round(time.monotonic()-t0,3),
                                   "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                                   "profiles": profiles})
        print("PASS", module, len(profiles), "axiom profiles", flush=True)
    receipt["seconds"] = round(time.monotonic() - started, 3)
    receipt["printed_axiom_profiles"] = sum(len(m["profiles"]) for m in receipt["modules"])
    (build / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("PASS_RG_ALGEBRAIC_REDUCTIONS", receipt["printed_axiom_profiles"], "profiles; global RG NOT_PROVED")
if __name__ == "__main__": main()
